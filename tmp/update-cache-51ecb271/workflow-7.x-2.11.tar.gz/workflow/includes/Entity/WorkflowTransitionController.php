<?php

/**
 * @file
 * Contains a stub class. 
 * The functionality is removed but apparently caches aren't refreshed 
 * properly during upgrade. 
 * @see https://www.drupal.org/node/2620530
 */

/**
 *
 */
class WorkflowTransitionController {
}
