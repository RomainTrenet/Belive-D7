This submodule contains the code to maintain workflows on nodes, using the classic Workflow way.
If a version of Workflow was installed, before 7.x-2.0, this module is enabled by default.
